<?php 

/**
 * Plugin Name: Webdevia main plugin
 * Plugin URI: http://www.themeforest.net/user/Mymoun
 * Description: Add features to Mymoun themes.
 * Version: 3.4
 * Author: Mymoun
 * Author URI: http://www.themeforest.net/user/Mymoun
 */


class WebdeviaMainPlugin {
    function __construct()
    {

require_once(  plugin_dir_path( __FILE__ ).'post-types.php' );
require_once(  plugin_dir_path( __FILE__ ).'meta-box.php' );
require_once(  plugin_dir_path( __FILE__ ).'/import/wd-import.php' );

require_once(  plugin_dir_path( __FILE__ ).'shortcode/latsone.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_pricing_table.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_client.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_team.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_portfolio.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_testimonial.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_single_post.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_countup.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_chartpie.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_icon_text.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_featured_box.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_flip_image.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_recent_blog.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_blog.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_google_map.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/progress_bars.php' );
require_once(  plugin_dir_path( __FILE__ ).'shortcode/phonerepair_modal.php' );


require_once(  plugin_dir_path( __FILE__ ).'widgets/aboutme.php' );
require_once(  plugin_dir_path( __FILE__ ).'widgets/one-post.php' );
require_once(  plugin_dir_path( __FILE__ ).'widgets/widget.php' );
require_once(  plugin_dir_path( __FILE__ ).'widgets/adress.php' );
        add_action( 'admin_enqueue_scripts', 'phonerepair_plugin_script' );
        function phonerepair_plugin_script(){
            wp_enqueue_script( 'phonerepair-plugin-script', plugin_dir_url( __FILE__ ) . '/js/upload-media.js', array( 'jquery' ) );
            wp_enqueue_script( 'phonerepair-plugin-import-script', plugin_dir_url( __FILE__ ) . '/js/import-script.js', array( 'jquery' ) );
        }
    }
}
new WebdeviaMainPlugin;
function image_from_url_relatives($image_url){
    $images=array();
    $images=explode('/',$image_url);
    $position=array_search('uploads',$images);
    $content=array();
    if($position){
        for($i=$position; $i<count($images);$i++) array_push($content,$images[$i]);
        $image_relative_link=get_site_url(). '/wp-content/'.implode('/',$content);
        if($image_url!=$image_relative_link) update_post_meta(get_the_ID(), 'pciture', $image_relative_link);
        return $image_relative_link;
    } else {
        return $image_url;
    }
}