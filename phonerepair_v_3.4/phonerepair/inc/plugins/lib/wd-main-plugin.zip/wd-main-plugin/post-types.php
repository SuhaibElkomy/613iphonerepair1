<?php 
/*-------------- portfolio custom posttyp -----------------------*/
 if( ! function_exists('phonerepair_portfolio_posttype')): 
  function phonerepair_portfolio_posttype() {
    register_post_type( 'portfolio',
      array(
        'labels' => array(
          'name' => __( 'Portfolio', 'webdevia' ),
          'singular_name' => __( 'portfolio', 'webdevia' ),
          'add_new' => __( 'Add New Portfolio Item', 'webdevia' ),
          'add_new_item' => __( 'Add New Portfolio Item', 'webdevia' ),
          'edit_item' => __( 'Edit portfolio', 'webdevia' ),
          'new_item' => __( 'Add New Portfolio Item', 'webdevia' ),
          'view_item' => __( 'View Portfolio Item', 'webdevia' ),
          'search_items' => __( 'Search Portfolio Item', 'webdevia' ),
          'not_found' => __( 'No Portfolio Item found', 'webdevia' ),
          'not_found_in_trash' => __( 'No Portfolio Item found in trash', 'webdevia' )
        ),
        'public' => true,
        'menu_icon' => 'dashicons-portfolio',
        'supports' => array( 'title', 'thumbnail', 'comments','editor'),
        'capability_type' => 'post',
        'rewrite' => array("slug" => "portfolio"), // Permalinks format
        'menu_position' => 5
      )
    );
    register_taxonomy( 'projet', 'portfolio', array( 'hierarchical' => true,
                               'label' => 'categories', 
                               'query_var' => true, 
                               'rewrite' => true ) );
  }
  add_action( 'init', 'phonerepair_portfolio_posttype' );
endif;


//----------------------- Custom type Team Member -----------------
if( ! function_exists('phonerepair_teammember_posttype')): 
  function phonerepair_teammember_posttype() {
    register_post_type( 'team-member',
      array(
        'labels' => array(
          'name' => __( 'Team Members', 'webdevia' ),
          'singular_name' => __( 'team member', 'webdevia' ),
          'add_new' => __( 'Add New Team Member', 'webdevia' ),
          'add_new_item' => __( 'Add New Team Member', 'webdevia' ),
          'edit_item' => __( 'Edit Team Member', 'webdevia' ),
          'new_item' => __( 'Add New Team Member', 'webdevia' ),
          'view_item' => __( 'View Team Member', 'webdevia' ),
          'search_items' => __( 'Search Team Member', 'webdevia' ),
          'not_found' => __( 'No Team Member found', 'webdevia' ),
          'not_found_in_trash' => __( 'No Team Member found in trash', 'webdevia' )
        ),
        'public' => true,
        'menu_icon' => 'dashicons-businessman',
        'supports' => array( 'title'),
        'capability_type' => 'post',
        'rewrite' => array("slug" => "team-member"), // Permalinks format
        'menu_position' => 5
      )
    );
  }
  add_action( 'init', 'phonerepair_teammember_posttype' );
endif;
//----------------------- Custom type Testimonials -----------------
if( ! function_exists('phonerepair_testimonials_posttype')):
  function phonerepair_testimonials_posttype() {
    register_post_type( 'testimonials',
      array(
        'labels' => array(
          'name' => __( 'Testimonials', 'webdevia' ),
          'singular_name' => __( 'testimonial', 'webdevia' ),
          'add_new' => __( 'Add New Testimonial', 'webdevia' ),
          'add_new_item' => __( 'Add New Testimonial', 'webdevia' ),
          'edit_item' => __( 'Edit Testimonial', 'webdevia' ),
          'new_item' => __( 'Add New Testimonial', 'webdevia' ),
          'view_item' => __( 'View Testimonial', 'webdevia' ),
          'search_items' => __( 'Search Testimonial', 'webdevia' ),
          'not_found' => __( 'No Testimonials found', 'webdevia' ),
          'not_found_in_trash' => __( 'No Testimonials found in trash', 'webdevia' )
        ),
        'public' => true,
        'menu_icon' 					=> 			'dashicons-format-quote',
        'supports' => array( 'title', 'excerpt'),
        'capability_type' => 'post',
        'rewrite' => array("slug" => "testimonials"), // Permalinks format
        'menu_position' => 5
      )
    );
  }
  add_action( 'init', 'phonerepair_testimonials_posttype' );
endif;

